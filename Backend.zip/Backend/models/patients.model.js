import mongoose from "mongoose";

const Schema = mongoose.Schema

const PatientsSchema = new Schema({
    firstname:{
        type:String,
        required:false
    },
    lastname:{
        type:String,
        required:false
    },
    dateofbirth:{
        type:Date,
        required:false
    },
    gender:{
        type:String,
        enum:["male","female","other"],
        required:false
    },
    email:{
        type:String,
        required:false
    },
    phone:{
        type:String,
        required:false
    },
})

export default mongoose.model("Patient",PatientsSchema)